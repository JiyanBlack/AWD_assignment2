export default function(data){

		return "123123";

}