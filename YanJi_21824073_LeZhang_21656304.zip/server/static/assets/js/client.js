import React from "react";
import ReactDOM from "react-dom";
import ChatWindow from  "./ChatWindow.js";



const app= document.getElementById("app");
ReactDOM.render(
	<ChatWindow/>
,app);