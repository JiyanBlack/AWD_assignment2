Setup:

npm install
node server/server.js